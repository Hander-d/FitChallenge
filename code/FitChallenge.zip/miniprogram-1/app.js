// app.js
App({
  onLaunch:function()
  {
    if(!wx.cloud)
    {
      console.error('请使用2.2.3')
    }
    else
    {
      wx.cloud.init({
        env:'cloud1',
      traceUser:true})
    }

  this.globalData = {
    userInfo : null
  }
}
})
