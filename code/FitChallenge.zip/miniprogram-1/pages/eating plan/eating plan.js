Page({
  bmidietmap : {
    "underweight": ["早餐：全麦面包、鸡蛋、牛奶、果汁", "午餐：糙米饭、炒菜、豆腐、牛肉", "晚餐：意大利面、烤鸡、蔬菜沙拉、酸奶"],
    "normal": ["早餐：麦片、牛奶、水果、全麦面包", "午餐：鱼肉、蔬菜、糙米饭、豆腐", "晚餐：烤鸡、蔬菜沙拉、土豆、酸奶"],
    "overweight": ["早餐：燕麦片、牛奶、水果、全麦面包", "午餐：鸡胸肉、蔬菜、糙米饭、豆腐", "晚餐：烤鱼、蔬菜沙拉、糙米饭、酸奶"],
    "mild_obesity": ["早餐：鸡蛋、牛奶、水果、全麦面包", "午餐：瘦肉、蔬菜、糙米饭、豆腐", "晚餐：烤鸡胸肉、蔬菜沙拉、糙米饭、酸奶"],
    "moderate_obesity": ["早餐：蛋白质粉、牛奶、水果、全麦面包", "午餐：瘦肉、蔬菜、糙米饭、豆腐", "晚餐：烤鱼、蔬菜沙拉、糙米饭、酸奶"],
    "severe_obesity": ["早餐：蛋白质粉、牛奶、水果、全麦面包", "午餐：鱼肉、蔬菜、糙米饭、豆腐", "晚餐：烤鸡胸肉、蔬菜沙拉、糙米饭、酸奶"]
  },
  /**
   * 页面的初始数据
   */
  data: {
    bmivalue:'',
    dietrecommend:[],
    bmiclass:''
  },
  getbmivalue(e)
  {
    this.setData({
      bmivalue:e.detail.value
    })
  },
  recommenddiet()
  {
    let bmivalue = this.data.bmivalue;
    let bmiclass = "";
    if(bmivalue < 18.5){
      bmiclass = "underweight";
    }
    else if (bmivalue < 24){
      bmiclass = "normal";
    }
    else if(bmivalue < 28){
      bmiclass = "overweight";
    }
    else if (bmivalue < 30){
      bmiclass = "mild_obesity";
    }
    else if (bmivalue < 35){
      bmiclass = "moderate_obesity";
    }
    else{
      bmiclass = "severe_obesity"
    }
    let dietrecommend = this.bmidietmap[bmiclass];
    this.setData({
      bmiclass:bmiclass,
      dietrecommend:dietrecommend
    })
    },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})