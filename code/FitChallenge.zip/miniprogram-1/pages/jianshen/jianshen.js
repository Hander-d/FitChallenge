// pages/jianshen/jianshen.js

Page({
  data: { 
    ishide:true,
    isjiantou:true,   //箭头切换
    selectcontent:[
      {id:1,name:"计划1"},
      {id:2,name:"计划2"},
      {id:3,name:"计划3"},
      {id:4,name:"计划4"},
      {id:5,name:"计划5"},
   ],
    i : 0,
    text:'',
    value:undefined,   //选中的值
    valueid:undefined,  //选中的id
    list:[
      "每周进行3次有氧运动，每次30分钟；每周进行3次力量训练，每次45分钟；每周进行2次瑜伽/普拉提训练，每次30分钟；每天保证充足的睡眠时间，喝足够的水，控制饮食，避免过度饮酒和吸烟；每周进行一次身体检查，记录体重、血压等指标，以跟踪进展。注意事项：逐渐增加训练强度，注意姿势和呼吸，避免过度运动造成疲劳和受伤；出现不适或疼痛时应停止运动并咨询医生。",
      "每周进行5次有氧运动，每次30-45分钟；每周进行3次力量训练，每次30-45分钟；每周进行2次瑜伽/普拉提训练，每次30-45分钟；每天保持充足的睡眠时间，喝足够的水，控制饮食，避免过度饮酒和吸烟；每周进行一次身体检查，记录体重、身体成分、血压等指标，以跟踪进展。注意热身、逐渐增加训练强度、注意姿势和呼吸、避免过度运动造成疲劳和受伤、出现不适或疼痛时应停止运动并咨询医生。",
      "每周进行3次全身力量训练，每次45-60分钟；每周进行2次HIIT训练，每次20-30分钟；每周进行2次有氧运动，每次30-45分钟；每天保证充足的睡眠时间，喝足够的水，控制饮食，避免过度饮酒和吸烟；每周进行一次身体检查，记录体重、身体成分、血压等指标，以跟踪进展。注意热身、逐渐增加训练强度、避免过度运动造成疲劳和受伤、出现不适或疼痛时应停止运动并咨询医生。"]
  },
    changetest(){
      var a = this.data.i + 1;
      this.setData({
        text:this.data.list[this.data.i%3],
      })
      this.setData({
        i : a
      })
    },
    // 下拉框收起和下拉
    changejiantou(){
      this.setData({
        isjiantou:!this.data.isjiantou
      })
    },
    // 选择数据后回显
    changecontent(e){
      this.setData({
        value:e.currentTarget.dataset.datavalue.name,
        valueid:e.currentTarget.dataset.datavalue.id,
        isjiantou:true
      })
    }
  })