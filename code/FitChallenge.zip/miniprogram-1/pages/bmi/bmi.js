Page({
  data: {
    bmi: null
  },
  calculateBMI: function (event) {
    const height = parseFloat(event.detail.value.height);
    const weight = parseFloat(event.detail.value.weight);
    if (isNaN(height) || isNaN(weight) || height <= 0 || weight <= 0) {
      wx.showToast({
        title: '请输入有效的身高和体重',
        icon: 'none'
      });
      return;
    }
    const bmi = weight / (height * height);
    this.setData({
      bmi: bmi
    });
    console.log(bmi)
  }
})