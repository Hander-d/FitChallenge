Page({
  data: {
    food: '',
    weight: null,
    calories: null,
    calorieList: [
      { name: '苹果', calorie: 0.52 },
      { name: '香蕉', calorie: 0.89 },
      { name: '鸡蛋', calorie: 1.55 },
      { name: '牛奶', calorie: 0.67 },
      { name: '米饭', calorie: 1.22 }
    ]
  },
  calculateCalories: function (event) {
    const food = event.detail.value.food;
    const weight = parseFloat(event.detail.value.weight);
    if (isNaN(weight) || weight <= 0) {
      wx.showToast({
        title: '请输入有效的重量',
        icon: 'none'
      });
      return;
    }
    const calorie = this.getCalorie(food);
    if (calorie === null) {
      wx.showToast({
        title: '没有找到对应的卡路里信息，请重新输入',
        icon: 'none'
      });
      return;
    }
    const calories = calorie * weight / 100;
    this.setData({
      food: food,
     weight: weight,
      calories: calories.toFixed(2)
    });
  },
  getCalorie: function (food) {
    for (let i = 0; i < this.data.calorieList.length; i++) {
      if (this.data.calorieList[i].name === food) {
        return this.data.calorieList[i].calorie;
      }
    }
    return null;
  }
})